import json
import pyrebase
 
config={
    "apiKey": "AIzaSyBY3-AxablC-wJr-uh8yUPQvvO6Wqo-qWk",
    "authDomain": "testsummarizer-c347d.firebaseapp.com",
    "databaseURL": "testsummarizer-c347d.firebaseio.com",
    "projectId": "testsummarizer-c347d",
    "storageBucket": "testsummarizer-c347d.appspot.com",
    "messagingSenderId": "199423768598",
    "appId": "1:199423768598:web:c96dbf7ba70fd8435e9d37",
    "measurementId": "G-7ZQ84EFFYD"
}

firebase = pyrebase.initialize_app(config)
auth=firebase.auth()

def registerUser(email,password):
  # print (email+" "+password)
  try:
    user=auth.create_user_with_email_and_password(email,password)
    return user
  except Exception as e: 
    error_json = e.args[1]
    error_msg = json.loads(error_json)['error']['message']
    error_code = json.loads(error_json)['error']['code']
    print(error_msg)
    print(error_code)
    return [error_code,error_msg]
  
def loginUser(email,password):
  try:
    user=auth.sign_in_with_email_and_password(email,password)
    return user
  except Exception as e: 
    error_json = e.args[1]
    error_msg = json.loads(error_json)['error']['message']
    error_code = json.loads(error_json)['error']['code']
    print(error_msg)
    print(error_code)
    return [error_code,error_msg]
  
def logoutUser():
  try:
    auth.current_user = None
    return auth.current_user
  except Exception as e: 
    error_json = e.args[1]
    error_msg = json.loads(error_json)['error']['message']
    error_code = json.loads(error_json)['error']['code']
    print(error_msg)
    print(error_code)
  return [error_code,error_msg]